// --- Вспомогательная функция для вывода результатов ---
function displayOutput(elementId, message, type = 'info') {
    const outputDiv = document.getElementById(elementId);
    if (!outputDiv) {
        console.error(`Элемент с ID ${elementId} не найден.`);
        return;
    }
    outputDiv.innerHTML = `<p class="output-message output-${type}">${message}</p>`;
    console.log(`[${elementId}] ${message}`);
}

// --- Задача 29: Масса пути ---
function calculateTrackMass(N_meters) {
    // Константы
    const RAIL_MASS_PER_METER = 65; // кг/м для Р-65
    const TIE_MASS = 270; // кг/шпала
    const TIES_PER_KM = 1840; // шт/км
    const FASTENER_MASS_PER_TIE = 2 * 12; // кг/шпала (2 крепления по 12кг)

    // Расчетные величины на метр
    const TIES_PER_METER = TIES_PER_KM / 1000; // шт/м
    const TIE_MASS_PER_METER = TIE_MASS * TIES_PER_METER; // кг/м шпал
    const FASTENER_MASS_PER_METER = FASTENER_MASS_PER_TIE * TIES_PER_METER; // кг/м крепежа

    let totalMass = 0;

    // Цикл для определения массы пути по N метрам
    for (let i = 0; i < N_meters; i++) {
        totalMass += RAIL_MASS_PER_METER;      // Масса рельсов на 1 метр
        totalMass += TIE_MASS_PER_METER;       // Масса шпал на 1 метр
        totalMass += FASTENER_MASS_PER_METER;  // Масса крепежа на 1 метр
    }

    displayOutput('massPathOutput',
        `Для ${N_meters} метров пути общая масса составит: ${totalMass.toFixed(2)} кг.`,
        'success'
    );
    return totalMass;
}

// Вызов функции для задачи "Масса пути"
const N_METERS_FOR_CALC = 100; // Пример: 100 метров
calculateTrackMass(N_METERS_FOR_CALC);


// --- Задача 29: Угадай число ---
let secretNumber;
let attemptsLeft;
let currentAttempt;
const MAX_ATTEMPTS = 10;
const MIN_NUMBER = 0;
const MAX_NUMBER = 1000;

function startGame() {
    secretNumber = Math.floor(Math.random() * (MAX_NUMBER - MIN_NUMBER + 1)) + MIN_NUMBER;
    attemptsLeft = MAX_ATTEMPTS;
    currentAttempt = 0;
    displayOutput('guessNumberOutput',
        `Я загадал число от ${MIN_NUMBER} до ${MAX_NUMBER}. У вас ${MAX_ATTEMPTS} попыток.`,
        'info'
    );
    // Добавляем кнопку снова после очистки вывода
    document.getElementById('guessNumberOutput').innerHTML += `<button onclick="makeGuess()">Сделать попытку</button>`;
    // Скрываем/отключаем кнопку "Начать игру", чтобы не спамить
    document.querySelector('#guessNumberOutput button:first-of-type').style.display = 'none';

    makeGuess(); // Сразу просим первую попытку
}

function makeGuess() {
    if (attemptsLeft <= 0) {
        displayOutput('guessNumberOutput',
            `Попытки закончились! Вы проиграли. Загаданное число было: ${secretNumber}.`,
            'error'
        );
        document.getElementById('guessNumberOutput').innerHTML += `<button onclick="startGame()">Начать игру заново</button>`;
        return;
    }

    currentAttempt++;
    attemptsLeft--;

    let guessInput = prompt(`Попытка ${currentAttempt} из ${MAX_ATTEMPTS}. Введите ваше число от ${MIN_NUMBER} до ${MAX_NUMBER}:`);
    let userGuess = parseInt(guessInput);

    // Проверка ввода
    if (isNaN(userGuess) || userGuess < MIN_NUMBER || userGuess > MAX_NUMBER) {
        displayOutput('guessNumberOutput',
            `Некорректный ввод. Пожалуйста, введите число от ${MIN_NUMBER} до ${MAX_NUMBER}. Попытки: ${MAX_ATTEMPTS - currentAttempt + 1} осталось.`,
            'error'
        );
        // Возвращаем попытку, так как ввод был некорректным
        attemptsLeft++;
        currentAttempt--;
        // Вызываем makeGuess снова, чтобы дать еще одну попытку с тем же номером
        makeGuess();
        return;
    }

    if (userGuess === secretNumber) {
        displayOutput('guessNumberOutput',
            `Поздравляем! Вы угадали число ${secretNumber} за ${currentAttempt} попыток!`,


'success'
        );
        document.getElementById('guessNumberOutput').innerHTML += `<button onclick="startGame()">Начать игру заново</button>`;
        attemptsLeft = 0; // Завершаем игру
    } else if (userGuess < secretNumber) {
        displayOutput('guessNumberOutput',
            `Мое число БОЛЬШЕ, чем ${userGuess}. Осталось попыток: ${attemptsLeft}.`,
            'info'
        );
        // Продолжаем игру, снова вызываем makeGuess
        makeGuess();
    } else {
        displayOutput('guessNumberOutput',
            `Мое число МЕНЬШЕ, чем ${userGuess}. Осталось попыток: ${attemptsLeft}.`,
            'info'
        );
        // Продолжаем игру, снова вызываем makeGuess
        makeGuess();
    }
}

// Первоначальный вызов для инициализации кнопки "Начать игру"
document.addEventListener('DOMContentLoaded', () => {
    const guessNumberDiv = document.getElementById('guessNumberOutput');
    if (guessNumberDiv) {
        guessNumberDiv.innerHTML = '<button onclick="startGame()">Начать игру "Угадай число"</button>';
    }
});