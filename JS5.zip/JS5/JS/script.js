// --- Вспомогательная функция для генерации массива ---
function generateRandomArray(size) {
    const arr = [];
    for (let i = 0; i < size; i++) {
        arr.push(Math.floor(Math.random() * 100) + 1); // Числа от 1 до 100
    }
    return arr;
}

// --- Вспомогательная функция для вывода результатов ---
function displayOutput(elementId, content) {
    const outputDiv = document.getElementById(elementId);
    if (outputDiv) {
        outputDiv.innerHTML = content;
    } else {
        console.error(`Элемент с ID ${elementId} не найден.`);
    }
}

// --- Задача 1: Обработка одномерного массива ---
function processArray() {
    const arraySizeInput = document.getElementById('arraySize');
    const arrayBInput = document.getElementById('arrayB');
    const initialArrayInput = document.getElementById('initialArray');

    const N = parseInt(arraySizeInput.value);
    const B = parseInt(arrayBInput.value);
    let originalArray = [];

    // Проверка на корректность N
    if (isNaN(N) || N <= 0) {
        displayOutput('arrayOutput1', '<p style="color: red;">Ошибка: Размерность массива N должна быть положительным числом.</p>');
        return;
    }

    // Попытка парсить введенный массив, если он есть
    const rawInitialArray = initialArrayInput.value.trim();
    if (rawInitialArray) {
        originalArray = rawInitialArray.split(',').map(numStr => parseInt(numStr.trim()));
        // Проверяем, все ли элементы были успешно преобразованы в числа
        if (originalArray.some(isNaN)) {
             displayOutput('arrayOutput1', '<p style="color: red;">Ошибка: Некорректный формат начального массива. Введите числа, разделенные запятыми.</p>');
             return;
        }
        // Если размерность N не совпадает с количеством введенных элементов, предупреждаем
        if (originalArray.length !== N) {
            displayOutput('arrayOutput1', `<p style="color: orange;">Внимание: Введенный массив имеет размер ${originalArray.length}, но указан N=${N}. Используем ${originalArray.length} элементов.</p>`);
            arraySizeInput.value = originalArray.length; // Обновляем N в форме
            // N_effective = originalArray.length; // Это не нужно, N уже будет корректным
        }
    } else {
        // Если массив не введен, генерируем случайный
        originalArray = generateRandomArray(N);
    }
    
    // Создаем копию массива для обработки
    const processedArray = [...originalArray]; // Используем spread operator для копирования

    let outputHtml = `<h3>Результаты обработки одномерного массива:</h3>`;
    outputHtml += `<p><strong>Начальный массив (N=${processedArray.length}):</strong> [${originalArray.join(', ')}]</p>`;
    outputHtml += `<p><strong>Число B:</strong> ${B}</p>`;

    if (processedArray.length === 0) {
        outputHtml += `<p style="color: orange;">Массив пуст, обработка невозможна.</p>`;
        displayOutput('arrayOutput1', outputHtml);
        return;
    }

    // Для пунктов б) и в) нам нужен последний элемент ИЗНАЧАЛЬНОГО массива
    // Сохраняем его до того, как массив будет изменен.
    const lastElementOfOriginal = originalArray[originalArray.length - 1];

    // а) Уменьшить на 20
    for (let i = 0; i < processedArray.length; i++) {
        processedArray[i] -= 20;
    }
    outputHtml += `<p><strong>После уменьшения на 20:</strong> [${processedArray.join(', ')}]</p>`;

    // б) Умножить на последний элемент (из ИСХОДНОГО массива)
    for (let i = 0; i < processedArray.length; i++) {
        processedArray[i] *= lastElementOfOriginal;
    }
    outputHtml += `<p><strong>После умножения на последний элемент начального массива (${lastElementOfOriginal}):</strong> [${processedArray.join(', ')}]</p>`;
    
    // в) Увеличить на число В
    for (let i = 0; i < processedArray.length; i++) {
        processedArray[i] += B;
    }
    outputHtml += `<p><strong>После увеличения на B (${B}):</strong> [${processedArray.join(', ')}]</p>`;

    displayOutput('arrayOutput1', outputHtml);
}

// --- Задача 2: Обработка двумерного массива ---
function processMatrix() {
    const matrixSizeInput = document.getElementById('matrixSize');
    const N = parseInt(matrixSizeInput.value);

    if (isNaN(N) || N < 2) {
        displayOutput('arrayOutput2', '<p style="color: red;">Ошибка: Размерность матрицы N должна быть числом не меньше 2.</p>');
        return;
    }

    const matrix = [];
    let outputHtml = `<h3>Результаты обработки двумерного массива:</h3>`;

    // Генерация случайного двумерного массива NxN
    outputHtml += `<h4>Сгенерированный массив (${N}x${N}):</h4>`;
    outputHtml += `<div style="display: flex; flex-direction: column; gap: 5px;">`;
    for (let i = 0; i < N; i++) {
        const row = [];
        outputHtml += `<div style="display: flex; gap: 10px;">`;
        for (let j = 0; j < N; j++) {
            const value = Math.floor(Math.random() * 100) + 1; // Числа от 1 до 100
            row.push(value);
            outputHtml += `<span style="display: inline-block; width: 40px; text-align: right; padding: 5px; border: 1px solid #eee; background-color: #fcfcfc;">${value}</span>`;
        }
        outputHtml += `</div>`;
        matrix.push(row);
    }
    outputHtml += `</div><br>`;

    // а) Какой элемент больше: левый верхний или правый верхний угол
    const topLeft = matrix[0][0];
    const topRight = matrix[0][N - 1];
    outputHtml += `<p><strong>Левый верхний элемент (0,0):</strong> ${topLeft}</p>`;
    outputHtml += `<p><strong>Правый верхний элемент (0,${N - 1}):</strong> ${topRight}</p>`;
    if (topLeft > topRight) {
        outputHtml += `<p><strong>Сравнение:</strong> Левый верхний (${topLeft}) больше правого верхнего (${topRight}).</p>`;
    } else if (topRight > topLeft) {
        outputHtml += `<p><strong>Сравнение:</strong> Правый верхний (${topRight}) больше левого верхнего (${topLeft}).</p>`;
    } else {
        outputHtml += `<p><strong>Сравнение:</strong> Левый верхний (${topLeft}) и правый верхний (${topRight}) равны.</p>`;
    }

    // б) Какой элемент меньше: правый нижний или левый верхний угол
    const bottomRight = matrix[N - 1][N - 1];
    // topLeft уже определен
    outputHtml += `<p><strong>Правый нижний элемент (${N - 1},${N - 1}):</strong> ${bottomRight}</p>`;
    outputHtml += `<p><strong>Левый верхний элемент (0,0):</strong> ${topLeft}</p>`;
    if (bottomRight < topLeft) {
        outputHtml += `<p><strong>Сравнение:</strong> Правый нижний (${bottomRight}) меньше левого верхнего (${topLeft}).</p>`;
    } else if (topLeft < bottomRight) {
        outputHtml += `<p><strong>Сравнение:</strong> Левый верхний (${topLeft}) меньше правого нижнего (${bottomRight}).</p>`;
    } else {
        outputHtml += `<p><strong>Сравнение:</strong> Правый нижний (${bottomRight}) и левый верхний (${topLeft}) равны.</p>`;
    }

    displayOutput('arrayOutput2', outputHtml);
}