// Функция для вывода результатов на страницу и в консоль (НА F12 УЫЫЫ)
function displayResult(taskName, description, result) {
    const outputDiv = document.getElementById('output');
    const p = document.createElement('p');
    p.innerHTML = `<strong>${taskName}:</strong> ${description} <br> <strong>Результат:</strong> ${result}`;
    outputDiv.appendChild(p);
    console.log(`${taskName}: ${description} Результат: ${result}`);
}

// ЗАДАЧКА 3

// Дано 4х-значное число. Если сумма 3 первых цифр меньше последней - заменить ее нулем, если больше или равно - ничего не делать. Вывести число на экран
let number3 = 1234; // Произвольное 4-значное число
let originalNumber3 = number3;

let numStr = String(number3);
if (numStr.length === 4) {
    let digit1 = parseInt(numStr[0]);
    let digit2 = parseInt(numStr[1]);
    let digit3 = parseInt(numStr[2]);
    let digit4 = parseInt(numStr[3]);

    let sumOfFirstThree = digit1 + digit2 + digit3;

    if (sumOfFirstThree < digit4) {
        // Заменяем последнюю цифру нулем 0_о
        numStr = numStr.substring(0, 3) + '0';
        number3 = parseInt(numStr);
    }
} else {
    console.log("Число не является 4-значным для Задачи 3.");
}
displayResult('Задача 3', `Исходное число: ${originalNumber3}`, `Новое число: ${number3}`);


// ЗАДАНИЕ БОЖЕ 24

// Даны два числа. Если квадратный корень из второго числа меньше первого числа, то увеличить второе число в пять раз. :О
let num1 = 10; // Произвольное первое число
let num2 = 25; // Произвольное второе число
let originalNum1_24 = num1;
let originalNum2_24 = num2;

let sqrtNum2 = Math.sqrt(num2);

if (sqrtNum2 < num1) {
    num2 *= 5;
}
displayResult('Задача 24', `Исходные числа: num1 = ${originalNum1_24}, num2 = ${originalNum2_24}`, `Новые числа: num1 = ${num1}, num2 = ${num2}`);




// ВНИМАНЕ!!! 
//Дополнительные тесты не были обязательным требованием по формированию ТВОЕГО задания, но они значительно улучшают качество и наглядность представленного решения, а также являются стандартной практикой в разработке ПО. ТЫ ОБЯЗАТЕЛЬНО можете их удалить, если считаете избыточными, но они приносят пользу.




// Дополнительные тесты для Задачи 3 
let number3_test1 = 5001; // Сумма первых трех (5) меньше последней (1) - не должно меняться, т.к. 5 < 1 - false
let originalNumber3_test1 = number3_test1;
let numStr_test1 = String(number3_test1);
if (numStr_test1.length === 4) {
    let digit1_t1 = parseInt(numStr_test1[0]);
    let digit2_t1 = parseInt(numStr_test1[1]);
    let digit3_t1 = parseInt(numStr_test1[2]);
    let digit4_t1 = parseInt(numStr_test1[3]);
    let sumOfFirstThree_t1 = digit1_t1 + digit2_t1 + digit3_t1;
    if (sumOfFirstThree_t1 < digit4_t1) {
        numStr_test1 = numStr_test1.substring(0, 3) + '0';
        number3_test1 = parseInt(numStr_test1);
    }
}
displayResult('Задача 3 (Тест 1)', `Исходное число: ${originalNumber3_test1}`, `Новое число: ${number3_test1}`);

let number3_test2 = 1115; // Сумма первых трех (3) меньше последней (5) - должно стать 1110
let originalNumber3_test2 = number3_test2;
let numStr_test2 = String(number3_test2);
if (numStr_test2.length === 4) {
    let digit1_t2 = parseInt(numStr_test2[0]);
    let digit2_t2 = parseInt(numStr_test2[1]);
    let digit3_t2 = parseInt(numStr_test2[2]);
    let digit4_t2 = parseInt(numStr_test2[3]);
    let sumOfFirstThree_t2 = digit1_t2 + digit2_t2 + digit3_t2;
    if (sumOfFirstThree_t2 < digit4_t2) {
        numStr_test2 = numStr_test2.substring(0, 3) + '0';
        number3_test2 = parseInt(numStr_test2);
    }
}
displayResult('Задача 3 (Тест 2)', `Исходное число: ${originalNumber3_test2}`, `Новое число: ${number3_test2}`);


// Дополнительные тесты для Задачи 24
let num1_test1 = 5;
let num2_test1 = 16; // sqrt(16) = 4, 4 < 5, значит num2_test1 должно увеличиться в 5 раз (16 * 5 = 80)
let originalNum1_24_test1 = num1_test1;
let originalNum2_24_test1 = num2_test1;
let sqrtNum2_test1 = Math.sqrt(num2_test1);
if (sqrtNum2_test1 < num1_test1) {
    num2_test1 *= 5;
}
displayResult('Задача 24 (Тест 1)', `Исходные числа: num1 = ${originalNum1_24_test1}, num2 = ${originalNum2_24_test1}`, `Новые числа: num1 = ${num1_test1}, num2 = ${num2_test1}`);

let num1_test2 = 3;
let num2_test2 = 9; // sqrt(9) = 3, 3 < 3 - false, значит num2_test2 не должно измениться
let originalNum1_24_test2 = num1_test2;
let originalNum2_24_test2 = num2_test2;
let sqrtNum2_test2 = Math.sqrt(num2_test2);
if (sqrtNum2_test2 < num1_test2) {
    num2_test2 *= 5;
}
displayResult('Задача 24 (Тест 2)', `Исходные числа: num1 = ${originalNum1_24_test2}, num2 = ${originalNum2_24_test2}`, `Новые числа: num1 = ${num1_test2}, num2 = ${num2_test2}`);